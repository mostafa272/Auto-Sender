﻿<?php
/**
 * Plugin for Joomla 3.0
 * License: http://www.gnu.org/licenses/gpl-2.0.html GNU/GPL
* @author Mostafa Shahiri
*/
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.plugin.plugin' );
if(!class_exists('ContentHelperRoute'))
 require_once (JPATH_SITE . '/components/com_content/helpers/route.php');

class plgContentautosender extends JPlugin {
/*function plgContentautosender($subject,$params){
 parent::__construct($subject, $params);
}
*/
	function onContentAfterSave($context, $article, $isNew)
	{
    if(JPluginHelper::isEnabled('content','autosender')==false) return;
     $config	= JFactory::getConfig();
     $mailer = JFactory::getMailer();
        $db	= JFactory::getDBO();
        $onlynew=$this->params->get('onlynew');
        $onlyintro=$this->params->get('onlyintro',0);
        $userid =$this->params->get('user_id',array());
        $artid=$this->params->get('art_id',array());
        $title =$this->params->get('title');
        $cats=$this->params->get('cat_id',array());
        $usergroup=$this->params->get('groups',array());
        $domain= str_replace('administrator/','',JUri::base());
        $images  = json_decode($article->images);
        if (isset($images->image_intro) && !empty($images->image_intro))
        $intro_img="<img src='".$domain.htmlspecialchars($images->image_intro)."' alt='".htmlspecialchars($images->image_intro_alt)."'>";
        else
        $intro_img='';
    if (isset($images->image_fulltext) && !empty($images->image_fulltext))
        $full_img="<img src='".$domain.htmlspecialchars($images->image_fulltext)."' alt='".htmlspecialchars($images->image_fulltext_alt)."'>";
        else
        $full_img='';
        $tmp_link = 'index.php?option=com_content&view=article&id='.$article->id;

		if ((int) $article->catid > 1)
		{
			$tmp_link .= '&catid='.$article->catid;
		}
       $url= str_replace('administrator/','',$domain.JRoute::_($tmp_link));
        $link='<a href="'.$url.'">'.$title.'</a>';

     if($article->state==1){
     $query="SELECT k.id as userid FROM #__users k";
     $db->setQuery($query);
     $result=$db->loadObjectList();
     foreach($result as $r)
     {
       $access=0;
        $allowed=1;
        if(isset($artid)){
            foreach($artid as $art)
         {  if($article->id==$art)
          $allowed=0;
           }
        }
       if(isset($cats)){
        foreach($cats as $cat)
        {
        if($article->catid==$cat)
        $allowed=0;
        }
        }
      $user = JFactory::getUser($r->userid);
      $groups	=  $user->getAuthorisedViewLevels();
      $group1=$user->getAuthorisedGroups();
        if(isset($userid)){
         foreach($userid as $buser)
         {  if($user->id==$buser)
          $allowed=0;
           }
          }
      foreach($groups as $group){
      if($article->access==$group)
      $access=1;
      }
      if(isset($usergroup)){
       foreach($usergroup as $temp)
        { foreach($group1 as $g){
          if($temp==$g)
           $allowed=0;
         }

        }
        }
      if($access && $allowed){
      $mailer->ClearAllRecipients();
      $sender = array($config->get( 'config.mailfrom' ),$config->get( 'config.fromname' ) );
       $mailer->setSender($sender);
       $mailer->addRecipient($user->email);
       $mailer->setSubject($article->title);
       $mailer->isHTML(true);
       $mailer->Encoding = 'base64';
       if($onlyintro){
       $mailer->setBody($intro_img.$article->introtext.$link);}
       else{
       $mailer->setBody($full_img.$article->introtext.$article->fulltext);
       }
       if($onlynew){
       if($isNew)
      $send = $mailer->Send();
      }
      else
      {
      $send = $mailer->Send();
      }
       if ( $send !== true ) {
        echo 'Error sending email';
        } else {
         echo 'Mail sent';
         }
      }
     }
     }
	}


}